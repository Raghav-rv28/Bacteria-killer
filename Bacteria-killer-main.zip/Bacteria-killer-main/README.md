# Bacteria-killer
COMP-4471 Project Using Vanilla Javascript and WEBGL library to create an animated game.
